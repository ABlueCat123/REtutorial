package com.github.abluecat123.retutorial.lesson1_3;

import org.bukkit.plugin.java.JavaPlugin;


public final class Lesson1_3 extends JavaPlugin {

    @Override
    public void onEnable() {

    }

    @Override
    public void onDisable() {

    }
}
