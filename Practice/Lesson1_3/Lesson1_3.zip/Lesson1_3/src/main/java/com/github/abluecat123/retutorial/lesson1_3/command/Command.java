package com.github.abluecat123.retutorial.lesson1_3.command;

import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class Command implements CommandExecutor{
    public boolean onCommand(CommandSender sender, org.bukkit.command.Command command, String label, String[] args) {
        return true;
    }

    private static boolean check(int a, int b, int c) {
        return true;
    }

}
