public class Main {

    public static void main(String[] args) {
        Father father = new Father();
        Father son = new Son();
        Son son1 = new Son();
        father.say();
        son.say();
        son1.say();
    }

    public static class Father
    {
        private static int ID = 0x114514;

        public void say()
        {
            new Thread(() -> System.out.println("It's a father class." + ID)).start();
        }
    }

    private static final class Son extends Father
    {
        private static final int ID = 114514;

        @Override
        public void say() {
            new Thread(() -> System.out.println("It's a son class." + ID)).start();
        }
    }
}
